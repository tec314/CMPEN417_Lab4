// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xfpga417_fir.h"

extern XFpga417_fir_Config XFpga417_fir_ConfigTable[];

#ifdef SDT
XFpga417_fir_Config *XFpga417_fir_LookupConfig(UINTPTR BaseAddress) {
	XFpga417_fir_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XFpga417_fir_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XFpga417_fir_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XFpga417_fir_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFpga417_fir_Initialize(XFpga417_fir *InstancePtr, UINTPTR BaseAddress) {
	XFpga417_fir_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFpga417_fir_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFpga417_fir_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XFpga417_fir_Config *XFpga417_fir_LookupConfig(u16 DeviceId) {
	XFpga417_fir_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XFPGA417_FIR_NUM_INSTANCES; Index++) {
		if (XFpga417_fir_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XFpga417_fir_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFpga417_fir_Initialize(XFpga417_fir *InstancePtr, u16 DeviceId) {
	XFpga417_fir_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFpga417_fir_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFpga417_fir_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

