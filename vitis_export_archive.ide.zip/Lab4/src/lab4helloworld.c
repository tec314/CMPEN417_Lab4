#include <stdio.h>
#include <stdlib.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h" // Parameter definitions for processor peripherals
#include "xscugic.h"     // Processor interrupt controller device driver
#include "xil_cache.h"
#include "xfpga417_fir.h"

// Instance Variable to Keep Reference to the HW
XFpga417_fir XFpga417_fir_inst;

void system_init();
void system_deinit();

int fpga417_init(XFpga417_fir *xFpga417_fir);
void fpga417_start(void *InstancePtr);

int run_hardware();

// Keep these small till further notice -- odd bug with the arm core...
#define DATA_LENGTH 8
#define FILTER_LENGTH 3

int main()
{
    system_init();

    // Initialize the IP Core
    int status;
    status = fpga417_init(&XFpga417_fir_inst);
    if (status != XST_SUCCESS) {
        print("HLS peripheral setup failed\n\r");
        exit(-1);
    }

    // Prepare the data to send to the hardware
    printf("Initializing Filter and Image\n");

    int length = DATA_LENGTH;
    int kernel_length = FILTER_LENGTH;

    // Initialize the input and filter arrays
    int input[DATA_LENGTH] = {
        1, 2, 3, 4, 5, 6, 7, 8
    };
    int coef[FILTER_LENGTH] = {3, 5, 3};  // Example filter coefficients

    // Create memory buffers for the input and filter data
    u32 *INPUT_BUFFER = (u32 *)(XPAR_PS7_DDR_0_S_AXI_BASEADDR + 0x20000); // Locate a memory reserved for AXI peripherals
    u32 *KERNEL_BUFFER = (u32 *)(XPAR_PS7_DDR_0_S_AXI_BASEADDR);

    // Clear the memory buffers
    memset(INPUT_BUFFER, 0, length * sizeof(u32));
    memset(KERNEL_BUFFER, 0, kernel_length * sizeof(u32));

    // Load the input and filter data into the buffers
    for (int i = 0; i < length; i++) {
        INPUT_BUFFER[i] = input[i];  // Assign values to input buffer
    }

    for (int i = 0; i < kernel_length; i++) {
        KERNEL_BUFFER[i] = coef[i];  // Assign values to kernel buffer
    }

    // Set the data variables of the arguments to the HW function
    XFpga417_fir_Set_data(&XFpga417_fir_inst, (uintptr_t)INPUT_BUFFER); // Using the Set_data function to load inputs
    XFpga417_fir_Set_filter(&XFpga417_fir_inst, (uintptr_t)KERNEL_BUFFER);  // Using the Set_filter function to load coefficients

    // Print input values for verification
    for (int i = 0; i < length; i++) {
        printf("Input data at index %d: %ld\n", i, INPUT_BUFFER[i]);
    }

    // Run the hardware
    int err = run_hardware(); // When this function returns, the result is ready
    if (err != 0) {
        printf("Error running hardware\n");
    }

    // Print the result (Output is in the INPUT_BUFFER now)
    printf("Filtered Output:\n");
    for (int i = 0; i < length; i++) {
        printf("Output data at index %d: %ld\n", i, INPUT_BUFFER[i]);
    }

    // Deinitialize the system
    system_deinit();

    return 0;
}

void system_deinit()
{
    printf("Cleaning up...\n");
    cleanup_platform();
}

void system_init()
{
    printf("Initializing Zynq Processing System\n");
    init_platform();
    Xil_DCacheEnable();
    srand(0);
    printf("System Initialization Complete..\n");
}

int run_hardware()
{
    // Flush the cache
    Xil_DCacheFlush();

    // Check if the hardware is ready
    if (XFpga417_fir_IsReady(&XFpga417_fir_inst)) {
        print("HLS peripheral is ready. Starting...\n");
    } else {
        print("!!! HLS peripheral is not ready! Exiting...\n\r");
        return 1;
    }

    // Start the hardware
    XFpga417_fir_Start(&XFpga417_fir_inst);

    // Wait until the operation is complete
    int c = 0;
    while (!XFpga417_fir_IsReady(&XFpga417_fir_inst)) {
        printf("Waiting for complete... %i\r", ++c);
    }

    // Invalidate the cache to get the results
    Xil_DCacheInvalidate();
    return 0;
}

int fpga417_init(XFpga417_fir *fpga_417_ptr)
{
    XFpga417_fir_Config *cfgPtr;
    int status;
    printf("Initializing Accelerator\n");

    // Look up the configuration for the IP
    cfgPtr = XFpga417_fir_LookupConfig(XPAR_FPGA417_FIR_0_DEVICE_ID);
    if (!cfgPtr) {
        fprintf(stderr, "ERROR: Lookup of accelerator configuration failed.\n\r");
        return XST_FAILURE;
    }
    print("SUCCESS: Lookup of accelerator configuration succeeded.\n\r");

    // Initialize the accelerator with the configuration
    status = XFpga417_fir_CfgInitialize(fpga_417_ptr, cfgPtr);
    if (status != XST_SUCCESS) {
        print("ERROR: Could not initialize accelerator.\n\r");
        return XST_FAILURE;
    }
    print("SUCCESS: initialized accelerator.\n\r");

    return status;
}

void fpga417_start(void *InstancePtr)
{
    XFpga417_fir *pAccelerator = (XFpga417_fir *)InstancePtr;
    XFpga417_fir_InterruptEnable(pAccelerator, 1);
    XFpga417_fir_InterruptGlobalEnable(pAccelerator);
    XFpga417_fir_Start(pAccelerator);
}
