// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xfpga417_fir.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFpga417_fir_CfgInitialize(XFpga417_fir *InstancePtr, XFpga417_fir_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Bus_a_BaseAddress = ConfigPtr->Bus_a_BaseAddress;
    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XFpga417_fir_Start(XFpga417_fir *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFpga417_fir_ReadReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_AP_CTRL) & 0x80;
    XFpga417_fir_WriteReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_AP_CTRL, Data | 0x01);
}

u32 XFpga417_fir_IsDone(XFpga417_fir *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFpga417_fir_ReadReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XFpga417_fir_IsIdle(XFpga417_fir *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFpga417_fir_ReadReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XFpga417_fir_IsReady(XFpga417_fir *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFpga417_fir_ReadReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XFpga417_fir_EnableAutoRestart(XFpga417_fir *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFpga417_fir_WriteReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_AP_CTRL, 0x80);
}

void XFpga417_fir_DisableAutoRestart(XFpga417_fir *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFpga417_fir_WriteReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_AP_CTRL, 0);
}

void XFpga417_fir_Set_data(XFpga417_fir *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFpga417_fir_WriteReg(InstancePtr->Control_BaseAddress, XFPGA417_FIR_CONTROL_ADDR_DATA_DATA, (u32)(Data));
    XFpga417_fir_WriteReg(InstancePtr->Control_BaseAddress, XFPGA417_FIR_CONTROL_ADDR_DATA_DATA + 4, (u32)(Data >> 32));
}

u64 XFpga417_fir_Get_data(XFpga417_fir *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFpga417_fir_ReadReg(InstancePtr->Control_BaseAddress, XFPGA417_FIR_CONTROL_ADDR_DATA_DATA);
    Data += (u64)XFpga417_fir_ReadReg(InstancePtr->Control_BaseAddress, XFPGA417_FIR_CONTROL_ADDR_DATA_DATA + 4) << 32;
    return Data;
}

void XFpga417_fir_Set_filter(XFpga417_fir *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFpga417_fir_WriteReg(InstancePtr->Control_BaseAddress, XFPGA417_FIR_CONTROL_ADDR_FILTER_DATA, (u32)(Data));
    XFpga417_fir_WriteReg(InstancePtr->Control_BaseAddress, XFPGA417_FIR_CONTROL_ADDR_FILTER_DATA + 4, (u32)(Data >> 32));
}

u64 XFpga417_fir_Get_filter(XFpga417_fir *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFpga417_fir_ReadReg(InstancePtr->Control_BaseAddress, XFPGA417_FIR_CONTROL_ADDR_FILTER_DATA);
    Data += (u64)XFpga417_fir_ReadReg(InstancePtr->Control_BaseAddress, XFPGA417_FIR_CONTROL_ADDR_FILTER_DATA + 4) << 32;
    return Data;
}

void XFpga417_fir_InterruptGlobalEnable(XFpga417_fir *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFpga417_fir_WriteReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_GIE, 1);
}

void XFpga417_fir_InterruptGlobalDisable(XFpga417_fir *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFpga417_fir_WriteReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_GIE, 0);
}

void XFpga417_fir_InterruptEnable(XFpga417_fir *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFpga417_fir_ReadReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_IER);
    XFpga417_fir_WriteReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_IER, Register | Mask);
}

void XFpga417_fir_InterruptDisable(XFpga417_fir *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFpga417_fir_ReadReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_IER);
    XFpga417_fir_WriteReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_IER, Register & (~Mask));
}

void XFpga417_fir_InterruptClear(XFpga417_fir *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFpga417_fir_WriteReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_ISR, Mask);
}

u32 XFpga417_fir_InterruptGetEnabled(XFpga417_fir *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFpga417_fir_ReadReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_IER);
}

u32 XFpga417_fir_InterruptGetStatus(XFpga417_fir *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFpga417_fir_ReadReg(InstancePtr->Bus_a_BaseAddress, XFPGA417_FIR_BUS_A_ADDR_ISR);
}

