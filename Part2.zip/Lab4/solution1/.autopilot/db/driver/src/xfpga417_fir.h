// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XFPGA417_FIR_H
#define XFPGA417_FIR_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xfpga417_fir_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Bus_a_BaseAddress;
    u32 Control_BaseAddress;
} XFpga417_fir_Config;
#endif

typedef struct {
    u64 Bus_a_BaseAddress;
    u64 Control_BaseAddress;
    u32 IsReady;
} XFpga417_fir;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XFpga417_fir_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XFpga417_fir_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XFpga417_fir_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XFpga417_fir_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XFpga417_fir_Initialize(XFpga417_fir *InstancePtr, u16 DeviceId);
XFpga417_fir_Config* XFpga417_fir_LookupConfig(u16 DeviceId);
int XFpga417_fir_CfgInitialize(XFpga417_fir *InstancePtr, XFpga417_fir_Config *ConfigPtr);
#else
int XFpga417_fir_Initialize(XFpga417_fir *InstancePtr, const char* InstanceName);
int XFpga417_fir_Release(XFpga417_fir *InstancePtr);
#endif

void XFpga417_fir_Start(XFpga417_fir *InstancePtr);
u32 XFpga417_fir_IsDone(XFpga417_fir *InstancePtr);
u32 XFpga417_fir_IsIdle(XFpga417_fir *InstancePtr);
u32 XFpga417_fir_IsReady(XFpga417_fir *InstancePtr);
void XFpga417_fir_EnableAutoRestart(XFpga417_fir *InstancePtr);
void XFpga417_fir_DisableAutoRestart(XFpga417_fir *InstancePtr);

void XFpga417_fir_Set_data(XFpga417_fir *InstancePtr, u64 Data);
u64 XFpga417_fir_Get_data(XFpga417_fir *InstancePtr);
void XFpga417_fir_Set_filter(XFpga417_fir *InstancePtr, u64 Data);
u64 XFpga417_fir_Get_filter(XFpga417_fir *InstancePtr);

void XFpga417_fir_InterruptGlobalEnable(XFpga417_fir *InstancePtr);
void XFpga417_fir_InterruptGlobalDisable(XFpga417_fir *InstancePtr);
void XFpga417_fir_InterruptEnable(XFpga417_fir *InstancePtr, u32 Mask);
void XFpga417_fir_InterruptDisable(XFpga417_fir *InstancePtr, u32 Mask);
void XFpga417_fir_InterruptClear(XFpga417_fir *InstancePtr, u32 Mask);
u32 XFpga417_fir_InterruptGetEnabled(XFpga417_fir *InstancePtr);
u32 XFpga417_fir_InterruptGetStatus(XFpga417_fir *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
